package PrjControleAlunos.example.PrjControleAlunos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjControleAlunosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjControleAlunosApplication.class, args);
	}

}
