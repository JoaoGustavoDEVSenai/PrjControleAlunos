package PrjControleAlunos.example.PrjControleAlunos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjControleAlunosApplicationTests {

	@Test
	void contextLoads() {
	}

}
